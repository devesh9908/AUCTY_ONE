<script src="js/responsiveslides.min.js"></script>
<script>
    $(function () {
      $("#slider").responsiveSlides({
      	auto: true,
      	speed: 500,
        namespace: "callbacks",
        pager: false,
        nav:true,
      });
    });
  </script>

<div class="banner">
	<div class="container">
		<div class="banner-main">
			<ul class="rslides" id="slider">
	        <li>
	  			<h3>AUCTY-ONE</h3>
				<p>We are Professional Auction Company</p>
				<div class="bann-btn">
					  <a href="#" class="hvr-shutter-out-horizontal">Read More</a>
               </div>
	        </li>
	       <li>
	  			<h3>AUCTY-ONE
				  </h3>
				<p>But this denouncing pleasure and praising</p>
				<div class="bann-btn">
					  <a href="#" class="hvr-shutter-out-horizontal">Read More</a>
               </div>
	        </li>
	        <li>
	        	<h3>AUCTY-ONE</h3>
				<p>We are Professional Auction Company</p>
				<div class="bann-btn">
					  <a href="#" class="hvr-shutter-out-horizontal">Read More</a>
               </div>
	        </li>
	      </ul>
		</div>
	</div>
</div>
<style type="text/css">
	#sidebar-menu > ul > li > a.active {
    color: #fff;
    background-color: #663366;
}
#sidebar-menu > ul > li > a.active {
    color: #fff;
    background-color: #5ec2e1;
}
#sidebar-menu > ul > li > a.active i {
    color: #fff;
}
#sidebar-menu > ul > li > a > i {
    display: inline-block;
    font-size: 18px;
    line-height: 17px;
    margin-left: 3px;
    margin-right: 10px;
    text-align: center;
    vertical-align: middle;
    width: 20px;
    color: #3f96b0;
}


</style>
<div class="left side-menu" style="border-right: 1px solid #663366 ">
 
		<div class="sidebar-inner slimscrollleft">
					
	<div class="bounce animated" id="sidebar-menu">

<ul>
	<!-- <li> <a href="dashboard.php" class="waves-effect"><i class="mdi mdi-home"></i><span> Home </span></a></li> -->

        
		  <li> <a href="dashboard.php" class="waves-effect"><i class="fa fa-home"></i><span> Dashboard </span></a></li>

          <li> <a href="users.php" class="waves-effect"><i class="fa fa-users"></i><span> Users </span></a></li>

          <li> <a href="seller.php" class="waves-effect"><i class="fa fa-user"></i><span> Seller </span></a></li>


          <li> <a href="product.php" class="waves-effect"><i class="fa fa-shopping-cart"></i><span> Product </span></a></li>




         
            <li> <a href="comments.php" class="waves-effect"><i class="fa fa-list-ol"></i><span> Comments </span></a></li>

            <li> <a href="soled.php" class="waves-effect"><i class="fa fa-first-order"></i><span> Soled Product </span></a></li>

            <li> <a href="contact.php" class="waves-effect"><i class="fa fa-first-order"></i><span> Contact us </span></a></li>

    	 
		<li> <a href="logout.php?logout" class="waves-effect"><i class="ion-log-out"></i><span> Logout </span></a></li>
		  
		  </ul>

             </div>
		  <div class="clearfix">
		  </div>
    </div>

</div>

<style type="text/css">
	
	#sidebar-menu ul ul li.active a {
    color: red;
}
</style>
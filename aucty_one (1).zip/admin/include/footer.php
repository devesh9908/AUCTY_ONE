<script> 
  
   $(".count_user").load("php/user_count.php?count_user");
    $(".count_seller").load("php/user_count.php?count_seller");
    $(".count_product").load("php/user_count.php?count_product");
    $(".count_product_soled").load("php/user_count.php?count_product_soled");


    
</script>



<?php
session_start();
require_once("config.php");
    $db = new dbObj();
	$conn =  $db->getConnstring();
 //print_r($_REQUEST);

 if(!empty($_REQUEST['pid']) && !empty($_REQUEST['message'])){

   if(isset($_SESSION['ID'])){

date_default_timezone_set('Asia/Calcutta');
// Now you can use date and time functions safely


      $date=date('Y-m-d');
      $time=date('h:i A');
      $user_id=$_SESSION['ID'];
      $user_name=$_SESSION['username'];
      $img=$_SESSION['img'];
      $message=$_REQUEST['message'];
      $pid=$_REQUEST['pid'];
$sql="INSERT INTO `comment` (`ID`, `product_id`, `date`, `time`, `user_id`, `message`) VALUES (NULL, '$pid', '$date', '$time', '$user_id', '$message');";


     $result= mysqli_query($conn,$sql);

     if($result){

 ?>
<div class="single-commemts" style="margin-bottom: 10px;">
			   	    <div class="col-md-2 user">
							<a href="#"><img style="width:70px;height: 70px;" src="admin/uploads/<?php echo $img; ?>" alt=""/></a>
						</div>
						<div class="col-md-10 user-comment"
							<a href="#"><h4><?php echo $user_name; ?></h4></a>
							<p><?php echo $message; ?></p>
						    <a class="comme" href="#"><?php echo $date; ?> <?php echo $time; ?></a>
						    
						</div>



                  <div class="clearfix"> </div>
			   </div>



 <?php


     }



   }else{

   	$_SESSION['pid']=$_REQUEST['pid'];

 	echo "<script>location='login.php';</script>";



   }




 }else{
 	echo "<script>alert('blank value not allowed');</script>";
 }

?>
<?php
session_start();
include("config.php");
$db = new dbObj();
$conn =  $db->getConnstring();

if(isset($_REQUEST['count_user'])){
 $sql="select count(*) as counter from user";
}elseif(isset($_REQUEST['count_seller'])){
 $sql="select count(*) as counter from seller";
}elseif(isset($_REQUEST['count_product'])){
 $sql="select count(*) as counter from product";
}elseif(isset($_REQUEST['count_product_soled'])){
 $sql="select count(*) as counter from product where user_id!=0";
}

$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
echo $row['counter'];
?>

<?php
	//include connection file 
	include_once("../config.php");
		
	$db = new dbObj();
	$connString =  $db->getConnstring();

	$params = $_REQUEST;
	
	$action = isset($params['action']) != '' ? $params['action'] : '';
	$empCls = new Employee($connString);

	switch($action) {
	 case 'add':
		$empCls->insertEmployee($params);
	 break;
	 case 'edit':
		$empCls->updateEmployee($params);
	 break;
	 case 'delete':
		$empCls->deleteEmployee($params);
	 break;
	 default:
	 $empCls->getEmployees($params);
	 return;
	}
	
	class Employee {
	protected $conn;
	protected $data = array();
	function __construct($connString) {
	$this->conn = $connString;
	}
	
	public function getEmployees($params) {
		
		$this->data = $this->getRecords($params);
		
		echo json_encode($this->data);
	}
	function insertEmployee($params) {
    
    extract($params);


	$tmp_name=$_FILES['photo']['tmp_name'];
	$date=date("Y-m-d");
	$time=date("h:i A");
	//echo $_SERVER['SERVER_NAME'];
    $randome=rand(100,9999);
    $file_name=$randome.$_FILES['photo']['name'];
	 
	if(move_uploaded_file($tmp_name, "../../uploads/".$file_name)){

	  

	  $sql="INSERT INTO `product` (`ID`, `product_name`, `date`, `time`, `price`, `description`, `seller_id`,`img`) VALUES (NULL, '$product_name', '$date', '$time', '$price', '$description', '$seller_id','$file_name');";

	  //echo $sql;
	}else{
		die('{"msg":"file not Uploaded","type":"warning","error":"0"}');
	}
	



  //echo "emtpy";
  




$result=mysqli_query($this->conn,$sql) or die('{"msg":"Data Not inserted","type":"warning","error":"0"}');
if($result){
	 echo '{"msg":"saved successfully","type":"success","error":"1"}';
}else{
	
	 echo  '{"msg":"Internal Server error - database","type":"warning","error":"0"}';

}


	}
	
	
	function getRecords($params) {
       $qtot = mysqli_query($this->conn,"SET NAMES utf8"); 

		$rp = isset($params['rowCount']) ? $params['rowCount'] : 10;
		
		if (isset($params['current'])) { $page  = $params['current']; } 
		else { 
			$page=1;
			$params['current']=0; 
		};  
        $start_from = ($page-1) * $rp;
		
		$sql = $sqlRec = $sqlTot = $where = '';
		
		 $where .=" WHERE user_id!=0 ";
		if( !empty($params['searchPhrase']) ) {   
			$where .=" And ";
			$where .=" ( ID LIKE '".$params['searchPhrase']."%' "; 
			$where .=" OR product_name LIKE '".$params['searchPhrase']."%'";   
			$where .=" OR price LIKE '".$params['searchPhrase']."%'";   
			$where .=" OR date LIKE '".$params['searchPhrase']."%'";   
			$where .=" OR time LIKE '".$params['searchPhrase']."%' )";
	   }
	   if( !empty($params['sort']) ) {  
			$where .=" ORDER By ".key($params['sort']) .' '.current($params['sort'])." ";
		}else{

            $where .= "ORDER BY ID DESC";

		}
	   // getting total number records without any search
		$sql = "SELECT *,(select name from seller where ID=product.seller_id) as seller_name,(select user_name from user where ID=product.user_id) as user_name FROM `product` ";
		$sqlTot .= $sql;
		$sqlRec .= $sql;
		
		//concatenate search sql if value exist
		if(isset($where) && $where != '') {

			$sqlTot .= $where;
			$sqlRec .= $where;
		}
		if ($rp!=-1)
		$sqlRec .= " LIMIT ". $start_from .",".$rp;
		
		//echo $sqlTot;
		
		$qtot = mysqli_query($this->conn, $sqlTot) or die("error to fetch tot employees data");
		$queryRecords = mysqli_query($this->conn, $sqlRec) or die("error to fetch employees data");
		
		while( $row = mysqli_fetch_assoc($queryRecords) ) { 



			$data[] = $row;
		}
if(empty($data)){
  $data=array();
}
		$json_data = array(
			"current"            => intval($params['current']), 
			"rowCount"            => 10, 			
			"total"    => intval($qtot->num_rows),
			"rows"            => $data   // total data array
			);
		
		return $json_data;
	}



function updateEmployee($params) {
		
  
  if(empty($params["user_id"])){

  	$sql = "UPDATE `product` SET `product_name` = '".$params["product_name"]."',
		`seller_id` = '" . $params["seller_id"]."',
		`price` = '" . $params["price"]."',
		`description` = '" . $params["description"]."'
		WHERE ID='".$params["edit_ID"]."'";

  }else{
  	$pdate=date('Y-m-d');
  	$ptime=date('h:i A');
  	$user_id=$params["user_id"];

  	 $sql = "UPDATE `product` SET `product_name` = '".$params["product_name"]."',
		`seller_id` = '" . $params["seller_id"]."',
		`price` = '" . $params["price"]."',
		`pdate` = '" . $pdate."',
		`ptime` = '" . $ptime."',
		`user_id` = '" . $user_id."',
		`description` = '" . $params["description"]."'
		WHERE ID='".$params["edit_ID"]."'";
 }

   $result = mysqli_query($this->conn, $sql) or die("error to update employee data");

 die('{"msg":"Updated successfully","type":"success","error":"1"}');


	
}
	
	function deleteEmployee($params) {

        

		$data = array();	
		//print_R($_POST);die;
		$sql = "delete from `product` WHERE ID='".$params["id"]."'";
		
		echo $result = mysqli_query($this->conn, $sql) or die("error to delete employee data");
	}
}
?>
	
<?php
    $id=$_GET['id'];
    require_once("../config.php");
    $db = new dbObj();
  $conn =  $db->getConnstring();
  mysqli_query($conn,"SET NAMES utf8");
  $sql="select *  from product where ID='$id'";
  $result = mysqli_query($conn,$sql);
  $rows =mysqli_fetch_array($result);
  
    //mysqli_close($conn);
   //print_r($rows);
?>



    <div class="row">

      <div class="col-lg-6">
                   <div  id="dvPreview">
                    <img style="width:200px;height:250px;" class="img img-thumbnail" src="<?php echo "uploads/".$rows['img']; ?>"><br>
                  </div>
                   
                   
                </div>



       <div class="col-md-6">
                 <div class="form-group">
                    <label for="name" class="control-label">Product Name:</label>
                    <input type="text" class="form-control" value="<?php echo $rows['product_name']; ?>" name="product_name" required />
                  </div>
        </div>


<div class="col-md-6">
                 <div class="form-group">
                    <label for="name" class="control-label">Select Seller:</label>

<select class="form-control" name="seller_id" required>
   <option value="">..select.. </option>
  <?php
    $res=mysqli_query($conn,"select * from seller");
    while($row=mysqli_fetch_array($res)){
  ?>
   <option value="<?php echo $row['ID']; ?>" <?php if($row['ID']==$rows['seller_id']){ echo "selected";} ?> ><?php echo $row['name']; ?></option>
   <?php
}
   ?>
</select>

                    
                  </div>
        </div>


        

        <div class="col-md-6">
                  <div class="form-group">
                    <label for="mobile" class="control-label">Price:</label>
                    <input type="number" class="form-control"  value="<?php echo $rows['price']; ?>" name="price"/>
                  </div>
       </div>


       <div class="col-md-6">
            <div class="form-group">
             <label for="gst" class="control-label">Description :</label>
             <textarea class="form-control"  name="description" required ><?php echo $rows['description']; ?></textarea>
             
           </div>
   
         </div>

         <div class="col-md-6">
                 <div class="form-group">
                    <label for="name" class="control-label">Sale to:</label>

<select class="form-control" name="user_id">
   <option value="">..select.. </option>
  <?php
    $res=mysqli_query($conn,"select * from user where type='user'");
    while($row=mysqli_fetch_array($res)){
  ?>
   <option value="<?php echo $row['ID']; ?>" <?php if($row['ID']==$rows['user_id']){ echo "selected";} ?> ><?php echo $row['user_name']; ?></option>
   <?php
}
   ?>
</select>

                    
                  </div>
        </div>
        
        
         </div>
</div>






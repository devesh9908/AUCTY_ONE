<?php
include("config.php");
$db = new dbObj();
$conn =  $db->getConnstring();
extract($_REQUEST);
if(!empty($user_name) && !empty($email) && !empty($mobile) && !empty($password)){

   

  $res=mysqli_query($conn,"select * from user where email='$email'");
  
  $num_rows=mysqli_num_rows($res);
  if($num_rows>0){

  	die("<div class='alert alert-danger'> Email Id aleady exist</div>");
  	

  }


  $sql="INSERT INTO `user` (`ID`, `user_name`, `mobile`, `email`, `password`) VALUES (NULL, '$user_name', '$mobile', '$email', '$password');";
 


$result=mysqli_query($conn,$sql);
if($result){
  	echo "<div class='alert alert-success'>User Register Successfully click to login...</div>";
	 
}else{
	
  	echo "<div class='alert alert-danger'>Internal Server Error</div>";
	

}

}else{
	echo "<div class='alert alert-danger'> Empty Value not Allowed </div>";
}


?>